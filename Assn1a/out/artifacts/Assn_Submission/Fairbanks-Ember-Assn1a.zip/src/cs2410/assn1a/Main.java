package cs2410.assn1a;

/**
 * @Fairbanks-Ember-Assn1a
 * @version 1.0
 */

public class Main {

    public static String fName="Ember", lName="Fairbanks";

    public static void printName()
    {
        System.out.println("My name is " + fName + " " + lName);
    }

    public static void main(String[] args)
    {
        printName();
    }
}